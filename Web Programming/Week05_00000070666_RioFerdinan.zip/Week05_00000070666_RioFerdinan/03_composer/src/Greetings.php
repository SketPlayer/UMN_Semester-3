<?php
namespace HelloWorld;

class Greetings {
    public static function sayHelloWorld() {
        return "Hello World";
    }
}