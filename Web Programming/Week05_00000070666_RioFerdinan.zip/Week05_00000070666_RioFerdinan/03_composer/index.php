<?php
require_once 'vendor/autoload.php';

use HelloWorld\Greetings;
echo Greetings::sayHelloWorld();