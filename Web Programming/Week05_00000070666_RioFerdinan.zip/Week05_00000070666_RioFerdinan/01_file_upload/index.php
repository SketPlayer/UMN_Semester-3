<!DOCTYPE html>
<html>
<head>
    <title>Simple File Upload</title>
</head>
<body>

<form action="proses.php" method="post" enctype="multipart/form-data">
    <input type="file" name="foto" />
    <button type="submit">Upload</button>
</form>
    
</body>
</html>