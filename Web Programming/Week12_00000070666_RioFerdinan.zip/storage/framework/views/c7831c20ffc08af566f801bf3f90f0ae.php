<h1>Daftar Mahasiswa</h1>
<a href="/students/create">Create new Student</a>
<table border="1">
    <tr>
        <th>NIM</th>
        <th>Foto</th>
        <th>Nama</th>
        <th>Prodi</th>
        <th>Jenis Kelamin</th>
        <th>Tanggal Lahir</th>
        <th>Hobi</th>
        <th>Tindakan</th>
    </tr>

    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($student->nim); ?></td>
        <td>
            <?php if($student->photo): ?>
                <img src="<?php echo e(asset("storage/{$student->photo}")); ?>" alt="<?php echo e($student->nama); ?>" style="max-width: 100px; max-height: 100px;">
            <?php else: ?>
                NULL
            <?php endif; ?>
        </td>
        <td><?php echo e($student->nama); ?></td>
        <td><?php echo e($student->prodi); ?></td>
        <td><?php echo e($student->gender); ?></td>
        <td><?php echo e($student->tanggal_lahir); ?></td>
        <td><?php echo e($student->hobi); ?></td>
        <td>
            <a href="/students/<?php echo e($student->id); ?>">SHOW</a> | 
            <a href="/students/<?php echo e($student->id); ?>/edit">EDIT</a> | 
            <form action="/students/<?php echo e($student->id); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit">DELETE</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Rio\CODING\Semester 3\Web Programming\Week-12\app-w12\resources\views/students/index.blade.php ENDPATH**/ ?>