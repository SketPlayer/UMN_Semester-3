<h1><?php echo e($student->nama); ?></h1>
<a href="/students">Back to Student List</a>
<br />
NIM: <?php echo e($student->nim); ?><br />
Nama: <?php echo e($student->nama); ?><br />
Prodi: <?php echo e($student->prodi); ?><br />
Jenis Kelamin: <?php echo e($student->gender); ?><br />
Tanggal Lahir: <?php echo e($student->tanggal_lahir); ?><br />
Hobi: <?php echo e($student->hobi); ?><br />
Foto: <img src="<?php echo e(asset($photo)); ?>" alt="<?php echo e($student->nama); ?>"/><?php /**PATH C:\Rio\CODING\Semester 3\Web Programming\Week-12\app-w12\resources\views/students/show.blade.php ENDPATH**/ ?>