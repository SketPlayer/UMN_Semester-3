<h1>Edit Student</h1>
<a href="/students">Back to Student List</a>

<?php if($errors): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<form action="/students/<?php echo e($student->id); ?>" method="post" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    NIM: <input type="text" name="nim" value="<?php echo e($student->nim); ?>" /><br />
    Nama: <input type="text" name="nama" value="<?php echo e($student->nama); ?>" /><br />
    Prodi: <input type="text" name="prodi" value="<?php echo e($student->prodi); ?>" /><br />
    <label for="gender">Jenis Kelamin:</label>
    <select name="gender" id="gender">
        <option value="Laki-laki" <?php echo e($student->gender === 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
        <option value="Perempuan" <?php echo e($student->gender === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
    </select> <br />
    Tanggal Lahir: <input type="date" name="tanggal_lahir" value="<?php echo e($student->tanggal_lahir); ?>" /><br />
    Hobi: <input type="text" name="hobi" value="<?php echo e($student->hobi); ?>" /><br />
    Foto: <img src="<?php echo e(asset("storage/{$student->photo}")); ?>" /><br />
    <input type="file" name="photo" />
    <button type="submit">Submit</button>
</form><?php /**PATH C:\Rio\CODING\Semester 3\Web Programming\Week-12\app-w12\resources\views/students/edit.blade.php ENDPATH**/ ?>