<?php
echo "rahasia";
echo "<br />";
echo password_hash("rahasia", PASSWORD_BCRYPT);