<?php
$dsn = "mysql:host=localhost;dbname=data_mahasiswa";
$kunci = new PDO($dsn, "root", "");
?>