<!DOCTYPE html>
<html>
<head>
    <title>App</title>
</head>
<body>

<h1>Hello World, this is the master layout.</h1>

<div class="container">
    @yield('content')
</div>

@yield('footer')
    
</body>
</html>