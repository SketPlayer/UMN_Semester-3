

<?php $__env->startSection('content'); ?>

    <h1>Data Mahasiswa</h1>
    <table border="1">
        <thead>
            <th>NIM</th>
            <th>Nama</th>
            <th>Prodi</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student['nim']); ?></td>
                    <td><?php echo e($student['nama']); ?></td>
                    <td><?php echo e($student['prodi']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>alert('Hello Visitor!')</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Rio\CODING\Semester 3\Web Programming\Week-9\app-w9\resources\views/students/index.blade.php ENDPATH**/ ?>