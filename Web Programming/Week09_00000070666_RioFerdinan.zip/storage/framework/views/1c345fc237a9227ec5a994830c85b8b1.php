<!DOCTYPE html>
<html>
<head>
    <title>App</title>
</head>
<body>

<h1>Hello World, this is the master layout.</h1>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php echo $__env->yieldContent('footer'); ?>
    
</body>
</html><?php /**PATH C:\Rio\CODING\Semester 3\Web Programming\Week-9\app-w9\resources\views/layout/app.blade.php ENDPATH**/ ?>