<form action="insert_proses.php" method="post">
    <input type="text" name="nim" placeholder="NIM" /><br />
    <input type="text" name="nama" placeholder="Nama" /><br />
    <input type="text" name="prodi" placeholder="Prodi" /><br />
    <input type="submit" />
</form>