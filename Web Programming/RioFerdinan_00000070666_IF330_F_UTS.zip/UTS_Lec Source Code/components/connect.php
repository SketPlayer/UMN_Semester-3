<?php

$db_host = 'sql104.byetclusterZ.com';
$db_name = 'if0_35294358_anbu';
$user_name = 'if0_35294358';
$user_password = 'H5GWbb7RZfW';

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $user_name, $user_password);

?>