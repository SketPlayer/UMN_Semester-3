<?php
echo "<h1>Pilih Object yang mau dibuat</h1><br />";
echo "<a href='form_sarjana.php'>Mahasiswa Sarjana</a>";
echo "<br />";
echo "<a href='form_magister.php'>Mahasiswa Magister</a>";

?>