<?php
$kon = mysqli_connect("localhost", "bakmidid_i", "7MtFA7q9%6T?", "bakmidid_db_restoran");
if (mysqli_connect_errno()) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
