<?php
  header("location: dashboard");
?>