<nav class="navbar navbar-light bg-light m-2">
    <div class="container">
        <span class="navbar-brand mb-0 h1">Hello World</span>
    </div>
</nav>