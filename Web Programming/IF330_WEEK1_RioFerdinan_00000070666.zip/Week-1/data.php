<?php
$nama = "John Thor";
?>